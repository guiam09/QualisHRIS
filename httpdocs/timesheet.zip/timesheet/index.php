<?php
	header("Location: view.php");
	die();
?>