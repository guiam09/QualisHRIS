<?php
include_once ('../includes/configuration.php');

include ('../db/connection.php');



// include login checker
$page_title="Admin";
$access_type ="Admin";

// include login checker
$require_login=true;
include_once "../includes/loginChecker.php";

include ('../includes/header.php');
include ('../includes/navbar.php');
include ('../includes/sidebar.php');
include ('../includes/fetchData.php');
include ('get_week_range.php');
?>
    <!-- Page -->
    <div class="page">
      <div class="page-header">
          <!--<h1 class="page-title"><i>Leave Application</i></h1>-->
      </div>
      <div class="page-content container-fluid">
          <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Time Sheets</h1>
          </div>

        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content-header -->
    <div class="row">
      <div class="col-12">
        <!-- Custom Tabs -->
        <div class="card">
          <div class="card-header d-flex p-0">
            <ul class="nav nav-pills p-2">
              <li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Timesheet Approval</a></li>
              <li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Approved Timesheets</a></li>
            </ul>
          </div><!-- /.card-header -->
          <div class="card-body table-responsive p-0">
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">


<?php

        if(isset($_POST['approveTimesheet'])){

                $approved=$_POST['submitted'];
                

                $ctr=-1;
                foreach ($approved as $id){
                    
                    $weeklyNumber = $id;
                    
                    $query_getDetails = "SELECT * FROM tbl_weeklyutilization
                    
                    WHERE weekly_ID=:weeklyNumber
                    ";
                    $stmt_getDetails=$con->prepare($query_getDetails);
                    
                    $stmt_getDetails->bindParam(':weeklyNumber',$weeklyNumber);
                    
                    $stmt_getDetails->execute();
                    
                    while($row_getDetails=$stmt_getDetails->fetch(PDO::FETCH_ASSOC)){
                        $employeeCode= $row_getDetails['employeeCode'];
                        $timeSubmitted= $row_getDetails['weekly_timeSubmitted'];
                        $dateSubmitted= $row_getDetails['weekly_dateSubmitted'];
                        $endDate= $row_getDetails['weekly_endDate'];
                    }

                    $query = "UPDATE tbl_weeklyutilization

                    SET
                        weekly_dateProcessed=:dateProcessed,
                        weekly_approval=:approval
                    WHERE
             
                        employeeCode=:employeeCode AND
                        weekly_timeSubmitted=:time AND
                        weekly_dateSubmitted=:date AND
                        weekly_endDate=:end
                        
                    ";
                    $stmt = $con->prepare($query);

                    //post values
//                    $timesheetID=$id;
                    $dateProcessed=date("Y-m-d");
                    //print_r($approved); 
                    
                    $approval="Approved";
                    
                    //echo "<br>";
                    //print_r($id);
                   // echo "<br><br>---------";
//                    $employeeCode = $id['employeeIDs'][0];
//                    $timeSubmitted = $id['timeSubmitted'][0];
//                    $dateSubmitted = $id['groupdateSubmitted'][0];
//                    $endDate = $id['groupendDate'][0];
//             

                    //bind
                  //  $stmt->bindParam(':timesheetID',$timesheetID);
                    $stmt->bindParam(':dateProcessed',$dateProcessed);
                    $stmt->bindParam(':approval',$approval);
                    $stmt->bindParam(':employeeCode',$employeeCode);
                    $stmt->bindParam(':time',$timeSubmitted);
                    $stmt->bindParam(':date',$dateSubmitted);
                    $stmt->bindParam(':end',$endDate);

                    if($stmt->execute()){
                        $ctr++;
                    }
                }
                if($ctr==0){
                    echo "<div class='alert alert-danger'>Approval Failed. No Timesheet Selected</div>";
                } else {
                    echo " <div class='alert alert-success'> ". $ctr  ." timesheet(s) approved</div>";
                }
            }
                  
                else if(isset($_POST['declineTimesheet']))    {
                    $declined=$_POST['submitted'];
                    $ctr=-1;
                    foreach ($declined as $id){
                            $weeklyNumber = $id;

                        $query_getDetails = "SELECT * FROM tbl_weeklyutilization

                        WHERE weekly_ID=:weeklyNumber
                        ";
                        $stmt_getDetails=$con->prepare($query_getDetails);

                        $stmt_getDetails->bindParam(':weeklyNumber',$weeklyNumber);

                        $stmt_getDetails->execute();

                        while($row_getDetails=$stmt_getDetails->fetch(PDO::FETCH_ASSOC)){
                            $employeeCode= $row_getDetails['employeeCode'];
                            $timeSubmitted= $row_getDetails['weekly_timeSubmitted'];
                            $dateSubmitted= $row_getDetails['weekly_dateSubmitted'];
                            $endDate= $row_getDetails['weekly_endDate'];
                        }
                        
                         $query = "UPDATE tbl_weeklyutilization

                                SET
                                    weekly_dateProcessed=:dateProcessed,
                                    weekly_approval=:approval
                                WHERE

                                    employeeCode=:employeeCode AND
                                    weekly_timeSubmitted=:time AND
                                    weekly_dateSubmitted=:date AND
                                    weekly_endDate=:end

                                ";
                        $stmt = $con->prepare($query);
                        $dateProcessed=date("Y-m-d");
                        $approval="Declined";
                        
                        $stmt->bindParam(':dateProcessed',$dateProcessed);
                        $stmt->bindParam(':approval',$approval);
                        $stmt->bindParam(':employeeCode',$employeeCode);
                        $stmt->bindParam(':time',$timeSubmitted);
                        $stmt->bindParam(':date',$dateSubmitted);
                        $stmt->bindParam(':end',$endDate);

                        if($stmt->execute()){
                            $ctr++;
                        }
                    }
                    if($ctr==0){
                        echo "<div class='alert alert-danger'>Approval Failed. No Timesheet Selected</div>";
                    } else {
                        echo " <div class='alert alert-success'> ". $ctr  ." timesheet(s) declined</div>";
                    }
                }
                



?>




                  <!--MAIN CONTENT-->
                  <div>
                  <?php
                    $query="SELECT * FROM tbl_weeklyutilization INNER JOIN tbl_employees ON tbl_employees.employeeCode = tbl_weeklyutilization.employeeCode
                    WHERE weekly_approval='Pending' GROUP BY employeeID, weekly_endDate, weekly_dateSubmitted ORDER BY weekly_endDate DESC
                    ";
                    $stmt=$con->prepare($query);
                    $stmt->execute();
                    $num=$stmt->rowCount();

                    if($num>0){
                        ?>
                      <form class="form-horizontal" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

                  <table id='example1' class='table table-hover table-striped'><br/>
                      <thead>
                      <tr>

                          <th></th>
                          <th>Week Ending</th>
                          <th>Employee Name</th>
                          <th>Hours</th>
                          <th>Date Submitted</th>
                          <th>Status</th>
                          <th>Date Processed</th>
                          <th>Approval</th>

                      </tr>
                          </thead>
                      <tbody>
                          <?php
//                         $rowCounter=0;
                        while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
                            $employeeNumber = $row['employeeCode'];
                            $dateSub = $row['weekly_dateSubmitted'];
                            $timeSub = $row['weekly_timeSubmitted'];
                            $dateEnd = $row['weekly_endDate'];

                      ?>

                            <tr>
                                <td><input type='checkbox' name='submitted[]'  value='<?php echo $row["weekly_ID"]; ?>' <?php if($row['weekly_approval'] == "Approved"){echo "DISABLED";} ?> >
                                    
                                </td>
                                <td>
                                    <a href="" data-toggle='modal' data-target='#viewtimesheetsss<?php echo $employeeNumber;?>' class="navbar-link"><input type='text' name='timesheet_ID' hidden value=' <?php echo $row['weekly_ID']; ?>'><?php echo $row['weekly_endDate'];?></a></td>

                                <td><?php echo $row['lastName'] . ", " . $row['firstName'] . " " . $row['middleName'] ;?></td>
                                <td><?php echo $row['weekly_overallTotal'];?></td>
                                <td><?php echo $row['weekly_dateSubmitted'];?></td>
                                <td><?php echo $row['weekly_status'];?></td>
                                <td><?php echo $row['weekly_dateProcessed'];?></td>
                                <td><?php echo $row['weekly_approval'];?></td>
                      </tr>
                      <?php
//                            $rowCounter=$rowCounter + 1;
                        }
                      ?>
                          <tr>
                              <td><input type='checkbox' name='submitted[]' value="" checked hidden></td>
                          </tr>
                          </tbody>
                      </table>
<!--    MODAL START                  -->
    
<!-- ^ MODAL END                     -->


                          <?php
//                        }
                        ?>
<!--
                      </tbody>
                  </table>

-->

<!--                          APPROVEDECLINE-->
                          <div class="btn-group pull-right" role="group" aria-label="Basic example">
  <button type="submit" class="btn btn-secondary" name="declineTimesheet">Decline</button>
  <button type="submit" class="btn btn-secondary" name="approveTimesheet">Approve</button>
</div>

                      </form>

                  <?php
                    }
        else {
            echo "No Timesheets submitted.";
        }
                    ?>


                  </div>

              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">

                <!-- /.content -->

<!--                  MAIN CONTENT TAB2-->

<?php
  $query_approve="SELECT * FROM tbl_weeklyutilization  INNER JOIN tbl_employees ON tbl_weeklyutilization.employeeCode = tbl_employees.employeeCode WHERE weekly_approval='Approved' GROUP BY employeeID, weekly_endDate, weekly_dateSubmitted ORDER BY weekly_endDate DESC
  ";
  $stmt_approve=$con->prepare($query_approve);
  $stmt_approve->execute();
  $num=$stmt_approve->rowCount();

  if($num>0){
      ?>
    <form class="form-horizontal" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

<table id='example1' class='table table-hover table-striped'><br/>
    <thead>
    <tr>

        
        <th>Week Ending</th>
        <th>Employee Name</th>
        <th>Hours</th>
        <th>Date Submitted</th>
        <th>Status</th>
        <th>Date Processed</th>
        <th>Approval</th>

    </tr>
        </thead>
    <tbody>
        <?php
//                         $rowCounter=0;
      while($row_approve=$stmt_approve->fetch(PDO::FETCH_ASSOC)){
          $employeeNumber = $row_approve['employeeCode'];
          $approvedTimeSubmit = $row_approve['weekly_timeSubmitted'];
          $approvedDateSubmit = $row_approve['weekly_dateSubmitted'];

    ?>

          <tr>
              
              <td><a href="#" data-toggle='modal' data-target='#viewtimesheetss<?php echo $employeeNumber; ?>'  class="navbar-link"><input type='text' name='timesheet_ID' hidden value=' <?php echo $row_approve['weekly_ID']; ?>'><?php echo $row_approve['weekly_endDate'];?></a></td>

              <td><?php echo $row_approve['lastName'] . ", " . $row_approve['firstName'] . " " . $row_approve['middleName'] ;?></td>
              <td><?php echo $row_approve['weekly_overallTotal'];?></td>
              <td><?php echo $row_approve['weekly_dateSubmitted'];?></td>
              <td><?php echo $row_approve['weekly_status'];?></td>
              <td><?php echo $row_approve['weekly_dateProcessed'];?></td>
              <td><?php echo $row_approve['weekly_approval'];?></td>
    </tr>
    <?php
//                            $rowCounter=$rowCounter + 1;
      }
    ?>
        </tbody>
    </table>
<!--    MODAL START                  -->
<?php
//                        $modalCounter=0;
//                          while($modalCounter<=$rowCounter) {

        ?>

<!-- ^ MODAL END                     -->


        <?php
//                        }
      ?>
<!--
    </tbody>
</table>

-->

<!--                          APPROVEDECLINE-->


    </form>

<?php
  }
else {
echo "No Timesheets submitted.";
}
  ?>




</div>

            </div>
            <!-- /.tab-content -->
          </div><!-- /.card-body -->
        </div>
        <!-- ./card -->
      </div>
      <!-- /.col -->
    </div>


    <!-- /.content -->
  </div>


<!-- MODALS -->

<?php
    $query3="SELECT * FROM tbl_weeklyutilization WHERE weekly_approval='Pending'
                    ";
                    $stmts=$con->prepare($query3);
                    $stmts->execute();
                    $nums=$stmts->rowCount();

    while($row_tables=$stmts->fetch(PDO::FETCH_ASSOC)){
        $employeeId = $row_tables['employeeCode'];
        $timeSubmitted = $row_tables['weekly_timeSubmitted'];
        $dateSubmitted = $row_tables['weekly_dateSubmitted'];
    ?>


    <div class = "modal fade" role = "dialog" id = "viewtimesheetsss<?php echo $employeeId; ?>">
        <div class = "modal-dialog modal-lg">
            <div class = "modal-content">
                <div class = "modal-header"> View Timesheet</div>
                <div class = "modal-body">



                <table id="classTable" class="table table-bordered">
                    <thead>
          </thead>
                    <tbody>
                    <tr>

                        <th class="col-sm-1">Project Code</th>
                        <th class="col-sm-1">Work Type</th>
                        <th class="col-sm-1">Task Code</th>
                        <th class="col-sm-1">Comments</th>
                        <th class="col-sm-1">Location</th>
                        <th class="col-sm-1">Mon</th>
                        <th class="col-sm-1">Tue</th>
                        <th class="col-sm-1">Wed</th>
                        <th class="col-sm-1">Thu</th>
                        <th class="col-sm-1">Fri</th>
                        <th class="col-sm-1">Sat</th>
                        <th class="col-sm-1">Sun</th>
                        <th class="col-sm-1">Total</th>
                    </tr>

                <?php

                            $query_table="SELECT * FROM tbl_weeklyutilization
                            INNER JOIN tbl_project ON tbl_weeklyutilization.project_ID = tbl_project.project_ID

                            INNER JOIN tbl_worktype ON tbl_weeklyutilization.work_ID = tbl_worktype.work_ID

                            INNER JOIN tbl_activityadmin ON tbl_weeklyutilization.activityAdmin_ID = tbl_activityadmin.activityAdmin_ID

                            INNER JOIN tbl_activityothers ON tbl_weeklyutilization.activityOthers_ID = tbl_activityothers.activityOthers_ID

                            INNER JOIN tbl_location ON tbl_weeklyutilization.location_ID = tbl_location.location_ID

                            WHERE employeeCode='". $employeeId ."'
                            AND weekly_timeSubmitted='". $timeSubmitted ."' AND weekly_dateSubmitted='". $dateSubmitted ."' AND weekly_approval='Pending'  GROUP BY weekly_ID
                            ";
                            $stmt_table=$con->prepare($query_table);
                            $stmt_table->execute();

                            $sundayTotal=0;
                            $mondayTotal=0;
                            $tuesdayTotal=0;
                            $wednesdayTotal=0;
                            $thursdayTotal=0;
                            $fridayTotal=0;
                            $saturdayTotal=0;
                            
        
                            while($row_table=$stmt_table->fetch(PDO::FETCH_ASSOC)){

                              ?>

                        <tr>
                            <td><?php echo $row_table['project_name'];?></td>
                            <td><?php echo $row_table['work_name'];?></td>


                            <?php

                                if($row_table['project_name']=="Admin") {
                                    echo "<td> ". $row_table['activityAdmin_name']." </td>";
                                }

                                else{
                                    echo "<td> ". $row_table['activityOthers_name']." </td>";
                                }
                            ?>

                            <td><?php echo $row_table['weekly_description'];?></td>
                            <td><?php echo $row_table['location_name'];?></td>
                            <td><?php echo $row_table['weekly_monday'];?></td>
                            <td><?php echo $row_table['weekly_tuesday'];?></td>
                            <td><?php echo $row_table['weekly_wednesday'];?></td>
                            <td><?php echo $row_table['weekly_thursday'];?></td>
                            <td><?php echo $row_table['weekly_friday'];?></td>
                            <td><?php echo $row_table['weekly_saturday'];?></td>
                            <td><?php echo $row_table['weekly_sunday'];?></td>
                            <td><?php echo $row_table['weekly_total'];?></td>


                          </tr>

                            <?php
                                $sundayTotal=$sundayTotal+ $row_table['weekly_sunday'];
                                $mondayTotal=$mondayTotal+ $row_table['weekly_monday'];
                                $tuesdayTotal=$tuesdayTotal+ $row_table['weekly_tuesday'];
                                $wednesdayTotal=$wednesdayTotal+ $row_table['weekly_wednesday'];
                                $thursdayTotal=$thursdayTotal+ $row_table['weekly_thursday'];
                                $fridayTotal=$fridayTotal+ $row_table['weekly_friday'];
                                $saturdayTotal=$saturdayTotal+ $row_table['weekly_saturday'];
                                $overallTotal=$row_table['weekly_overallTotal'];
//                                $modalCounter = $modalCounter + 1;
                            }
//                          }
                            ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <th>Total</th>
                            <th><?php echo $mondayTotal;?></th>
                            <th><?php echo $tuesdayTotal;?></th>
                            <th><?php echo $wednesdayTotal;?></th>
                            <th><?php echo $thursdayTotal;?></th>
                            <th><?php echo $fridayTotal;?></th>
                            <th><?php echo $saturdayTotal;?></th>
                            <th><?php echo $sundayTotal;?></th>
                            <th><?php echo $overallTotal;?></th>
                        </tr>
                    </tbody>

                </table>


                <div class = "modal-footer"></div>
            </div>
        </div>
    </div>
    </div>


<!--        Modal for Approved-->
        <?php
        $query4="SELECT * FROM tbl_weeklyutilization WHERE weekly_approval='Approved'
                    ";
                    $stmt4=$con->prepare($query4);
                    $stmt4->execute();
                    $num4=$stmt4->rowCount();

    while($row_table4=$stmt4->fetch(PDO::FETCH_ASSOC)){
        $employeeId4 = $row_table4['employeeCode'];
        $timeSubmitted4 = $row_table4['weekly_timeSubmitted'];
        $dateSubmitted4 = $row_table4['weekly_dateSubmitted'];
    ?>


    <div class = "modal fade" role = "dialog" id ="viewtimesheetss<?php echo $employeeId4; ?>">
        <div class = "modal-dialog modal-lg">
            <div class = "modal-content">
                <div class = "modal-header"> View Timesheet</div>
                <div class = "modal-body">



                <table id="classTable" class="table table-bordered">
                    <thead>
          </thead>
                    <tbody>
                    <tr>

                        <th class="col-sm-1">Project Code</th>
                        <th class="col-sm-1">Work Type</th>
                        <th class="col-sm-1">Task Code</th>
                        <th class="col-sm-1">Comments</th>
                        <th class="col-sm-1">Location</th>
                        <th class="col-sm-1">Mon</th>
                        <th class="col-sm-1">Tue</th>
                        <th class="col-sm-1">Wed</th>
                        <th class="col-sm-1">Thu</th>
                        <th class="col-sm-1">Fri</th>
                        <th class="col-sm-1">Sat</th>
                        <th class="col-sm-1">Sun</th>
                        <th class="col-sm-1">Total</th>
                    </tr>

                <?php

                            $query_table5="SELECT * FROM tbl_weeklyutilization



                            INNER JOIN tbl_project ON tbl_weeklyutilization.project_ID = tbl_project.project_ID

                            INNER JOIN tbl_worktype ON tbl_weeklyutilization.work_ID = tbl_worktype.work_ID

                            INNER JOIN tbl_activityadmin ON tbl_weeklyutilization.activityAdmin_ID = tbl_activityadmin.activityAdmin_ID

                            INNER JOIN tbl_activityothers ON tbl_weeklyutilization.activityOthers_ID = tbl_activityothers.activityOthers_ID

                            INNER JOIN tbl_location ON tbl_weeklyutilization.location_ID = tbl_location.location_ID

                            WHERE employeeCode='". $employeeId4 ."'
                            AND weekly_timeSubmitted='". $timeSubmitted4 ."' AND weekly_dateSubmitted='". $dateSubmitted4 ."' AND weekly_approval='Approved'  GROUP BY weekly_ID
                            ";
                            $stmt_table5=$con->prepare($query_table5);
                            $stmt_table5->execute();
        
                            $sundayTotalApproved=0;
                            $mondayTotalApproved=0;
                            $tuesdayTotalApproved=0;
                            $wednesdayTotalApproved=0;
                            $thursdayTotalApproved=0;
                            $fridayTotalApproved=0;
                            $saturdayTotalApproved=0;
        

                            while($row_table5=$stmt_table5->fetch(PDO::FETCH_ASSOC)){

                              ?>

                        <tr>
                            <td><?php echo $row_table5['project_name'];?></td>
                            <td><?php echo $row_table5['work_name'];?></td>


                            <?php

                                if($row_table5['project_name']=="Admin") {
                                    echo "<td> ". $row_table5['activityAdmin_name']." </td>";
                                }

                                else{
                                    echo "<td> ". $row_table5['activityOthers_name']." </td>";
                                }
                            ?>

                            <td><?php echo $row_table5['weekly_description'];?></td>
                            <td><?php echo $row_table5['location_name'];?></td>
                            <td><?php echo $row_table5['weekly_monday'];?></td>
                            <td><?php echo $row_table5['weekly_tuesday'];?></td>
                            <td><?php echo $row_table5['weekly_wednesday'];?></td>
                            <td><?php echo $row_table5['weekly_thursday'];?></td>
                            <td><?php echo $row_table5['weekly_friday'];?></td>
                            <td><?php echo $row_table5['weekly_saturday'];?></td>
                            <td><?php echo $row_table5['weekly_sunday'];?></td>
                            <td><?php echo $row_table5['weekly_total'];?></td>


                          </tr>

                            <?php
                                $sundayTotalApproved=$sundayTotalApproved+ $row_table5['weekly_sunday'];
                                $mondayTotalApproved=$mondayTotalApproved+ $row_table5['weekly_monday'];
                                $tuesdayTotalApproved=$tuesdayTotalApproved+ $row_table5['weekly_tuesday'];
                                $wednesdayTotalApproved=$wednesdayTotalApproved+ $row_table5['weekly_wednesday'];
                                $thursdayTotalApproved=$thursdayTotalApproved+ $row_table5['weekly_thursday'];
                                $fridayTotalApproved=$fridayTotalApproved+ $row_table5['weekly_friday'];
                                $saturdayTotalApproved=$saturdayTotalApproved+ $row_table5['weekly_saturday'];
                                $overallTotalApproved=$row_table5['weekly_overallTotal'];
//                                $modalCounter = $modalCounter + 1;
                            }
//                          }
                            ?>
                        
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <th>Total</th>
                            <th><?php echo $mondayTotalApproved;?></th>
                            <th><?php echo $tuesdayTotalApproved;?></th>
                            <th><?php echo $wednesdayTotalApproved;?></th>
                            <th><?php echo $thursdayTotalApproved;?></th>
                            <th><?php echo $fridayTotalApproved;?></th>
                            <th><?php echo $saturdayTotalApproved;?></th>
                            <th><?php echo $sundayTotalApproved;?></th>
                            <th><?php echo $overallTotalApproved;?></th>
                        </tr>
                    </tbody>

                </table>


                    <div class = "modal-footer"><button type='submit' name='printTimesheet'>Print</button></div>
            </div>
        </div>
    </div>
        </div>
    <?php



    }

    }
    ?>
      </div>
    </div>
    <!-- End Page -->


<!-- ADD MODAL -->
<div class="modal fade" id="exampleFormModal" aria-hidden="false" aria-labelledby="exampleFormModalLabel"
  role="dialog" tabindex="-1">
  <div class="modal-dialog modal-simple">
    <form class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="exampleFormModalLabel">Add Designation</h4>
      </div>
      <div class="modal-body">
        <form>
                   <div class="form-group form-material row">
                     <label class="col-md-4 col-form-label">Designation Name: </label>
                     <div class="col-md-8">
                       <input type="text" class="form-control" name="name" placeholder="Designation Name" autocomplete="off"
                       />
                     </div>
                   </div>
                   <div class="form-group form-material row">
                     <label class="col-md-4 col-form-label">Designation Description: </label>
                     <div class="col-md-8">
                       <textarea class="form-control" placeholder="Briefly Describe"></textarea>
                     </div>
                   </div>
                    <div class="form-group form-material row">
                       <label class="col-md-4 col-form-label" for="inputBasicEmail">Select Employees</label>
                       <div class="col-md-8">
                         <select class="form-control" required name="gender" multiple data-plugin="select2" data-placeholder="Select Here">
                           <option></option>
                             <option value="AK">Male</option>
                             <option value="HI">Female</option>
                         </select>
                       </div>
                 </div>
                 <br>
                   <div class="form-group form-material row">
                     <div class="col-md-9">
                       <button type="button" class="btn btn-primary">Submit </button>
                     </div>
                   </div>
                 </form>

      </div>
    </form>
  </div>
</div>
<!-- END ADD MODAL-->

    <!-- Footer -->
<?php
include ('../includes/footer.php');
include ('../includes/scripts.php');
 ?>


  </body>
</html>
