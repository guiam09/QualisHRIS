<?php
	include("weblock.php");
?>
<!DOCTYPE HTML>
<html>
<?php
include("head.php");

?>
<style>
    @media print
{    
    .no-print, .no-print *
    {
        display: none !important;
    }
}
</style>
<body>
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
	   <div class="mother-grid-inner">
             <?php
				include("header.php");
			?>
				
		<div class="four-grids">
					<div class="col-md-3 four-grid">
						<div class="four-agileits">
							<div class="icon">
								<i class="glyphicon glyphicon-log-in" aria-hidden="true"></i>
							</div>
							
							<div class="four-text">
								<h3>Check-in Time</h3>
								<h4>
								    <?php
								        //for settings
								        include("php_connect.php");
                				        $intime = "SELECT * FROM settings WHERE SettingsID=1";
                						$resintime = mysqli_query($conn, $intime);
                						$rowintime = mysqli_fetch_array($resintime);
                						echo date_format(date_create($rowintime["StandardIn"]), "h:ia");
								    ?>
								</h4>
								
							</div>
							
						</div>
					</div>
					<div class="col-md-3 four-grid">
						<div class="four-agileinfo">
							<div class="icon">
								<i class="glyphicon glyphicon-log-out" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3>Check-out Time</h3>
								<h4>
								    <?
								    echo date_format(date_create($rowintime["StandardOut"]), "h:ia");
								    ?>
								</h4>

							</div>
							
						</div>
					</div>
					<div class="col-md-3 four-grid">
						<div class="four-w3ls">
							<div class="icon">
								<i class="glyphicon glyphicon-ok" aria-hidden="true"></i>
							</div>
							<a href="directory.php">
							<div class="four-text">
								<h3>Check-ins</h3>
								<h4>
								    <?php
								    $cntroom = "SELECT COUNT(*) as cnt FROM room WHERE Status='IN-USE'";
                					$rescntroom = mysqli_query($conn,$cntroom);
                					$rowcntroom = mysqli_fetch_array($rescntroom);
                					echo $rowcntroom["cnt"];
								    ?>
								</h4>
								
							</div>
							</a>
							
						</div>
					</div>
					<div class="col-md-3 four-grid">
						<div class="four-wthree">
							<div class="icon">
								<i class="glyphicon glyphicon-calendar" aria-hidden="true"></i>
							</div>
							<a href="reservation_list.php">
							<div class="four-text">
								<h3>Reservations</h3>
								<h4>
								    <?php
                					$cntres = "SELECT COUNT(*) as cntres FROM reservation WHERE Status IN ('PAID', 'PENDING')";
                					$rescntres = mysqli_query($conn,$cntres);
                					$rowcntres = mysqli_fetch_array($rescntres);
                					echo $rowcntres["cntres"];
                				  ?>			    
								</h4>
							</div>
							</a>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
<!--//four-grids here-->
<!--agileinfo-grap-->
<div class="agileinfo-grap">
    <?php
    include("con_index.php");
    ?>
</div>
	<!--//agileinfo-grap-->
<!--photoday-section-->	
			
                        
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block" style="clear:both; height:5px">

</div>
<!--inner block end here-->
<!--copy rights start here-->
<div class="copyrights">
	 <p>© 2019 Astraea Guest House | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>	
<!--COPY rights end here-->
</div>
</div>
  <!--//content-inner-->
			<?php
			include("sidebar.php");
			?>
							  <div class="clearfix"></div>		
							</div>
			<?php
			include("js.php");
			?>
</body>
</html>