<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Astraea Guest House</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link rel="icon" href="images/favico.ico">

<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet">
<link rel="stylesheet" href="css/jquery-ui.css"> 
<!-- jQuery -->
<script src="js/jquery-2.1.4.min.js"></script>
<!-- //jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->

<style>
	body{
		background-color:white !important;
	}
</style>

</head> 
<body style="background-color:white !important;">
	<div class="main-wthree" style="background-color:white !important;">
	<div class="container" style="background-color:white !important;">
	<div class="sin-w3-agile" style="background-color:white !important;">
	    	<center><img src="images/a_logo.png" width="300px" /></center>
		<h2 style="color:green;">
		     <?php
							if(isset($_GET['res'])){
			    				$resp = $_GET['res'];
			    				if ($resp=="Log-in successful"){
			    					echo "
			    					<script>
			    					    window.location.href='index.php';
			    					</script>
			    					";
			    				}
								else{
									echo $resp;
			    				}
			    			}
							else{
								echo "Please Log-in";
							}
			  ?>
		</h2>
	
		<form action="in.php" method="post">
			<div class="username">
				<span class="username">Username:</span>
				<input type="text" name="name" class="name" placeholder="" required="" maxlength="30" style="background-color:#ffffad !important;">
				<div class="clearfix"></div>
			</div>
			<div class="password-agileits">
				<span class="username">Password:</span>
				<input type="password"  maxlength="30" name="password" class="password" placeholder="" required="" style="background-color:#ffffad !important;">
				<div class="clearfix"></div>
			</div>
			<div class="login-w3">
					<input type="submit" class="login" name="login" value="Sign In">
			</div>
			<div class="clearfix"></div>
		</form>
				
				
	</div>
	</div>
	</div>
</body>
</html>