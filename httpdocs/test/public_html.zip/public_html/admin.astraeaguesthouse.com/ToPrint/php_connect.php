<?php
$conn=mysqli_connect("localhost","root","","astraeah_db2");
?>