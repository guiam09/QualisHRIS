<?php
$conn=mysqli_connect("localhost","astraea","astraea123","astraeah_db2");
?>