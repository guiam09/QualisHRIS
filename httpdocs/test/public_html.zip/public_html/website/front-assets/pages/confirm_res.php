<!DOCTYPE html>
<html>
	<head>
		<title>Astraea Guest House | Confirm Reservation </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- FONTS -->
    <link rel="icon" href="../img/favicos.ico">
        <link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css">

         <style type="text/css">
           @import url(https://fonts.googleapis.com/css?family=Montserrat:400,700);
         </style> 

    <!-- HEADER AND NAVIGATION-->
        <link rel="stylesheet" type="text/css" href="../css/style.css"/>
        <link rel="stylesheet" href="../css/navstyle.css">

           <script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
           <script src="../js/navstyle.js"></script>

    <!-- CONTACT -->
        <link rel="stylesheet" type="text/css" href="../css/contact.css"/>

        <!-- CONTACT -->
        <link rel="stylesheet" type="text/css" href="../css/map.css"/>

 <link rel="stylesheet" type="text/css" href="../css/footer.css"/>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cdn.jsdelivr.net/jquery.slick/1.5.0/slick.min.js'></script>
		
		
		
		<script src="Inputmask-2.x/dist/jquery.inputmask.bundle.min.js"></script>

		<!-- SWAL -->
	<script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">

		
	</head>

<body>
		
<header>

  <img class="logo" src="../img/a_logo.png" width="70%" height="auto" style="max-width:230px; "/>
   

<div id='cssmenu'>
  <ul>
    <li><a href='../../index.php'>HOME</a></li>
    <li><a href='rooms-index.php'>ROOMS & RATES</a></li>
    <li><a href='gallery.php'>GALLERY</a></li>
    <li class='active'><a href='#'>RESERVATION</a>
      <ul>
        <?php
          //Copy this block of code IZA:
          session_start();
          if(isset($_SESSION["res_in"])){
          ?>
          
          
         <li><a href='reserve.php'>BOOK YOUR STAY</a>
         </li>
         
         <?php
         }
         //end of block of code
         ?>
        <li><a href='modify.php'>MODIFY RESERVATION</a></li>
        <li><a href='submitproof.php'>SUBMIT PROOF OF PAYMENT</a> </li>
      </ul>
   </li>
    <li><a href='#'>CONTACT US</a></li>
   <?php
   	if(!isset($_SESSION['guest_id'])) {
   ?>
   		<li><a href='login.php'>LOGIN</a></li>
   <?php
   	} else {
   ?>
   		<li><a href='logout.php'>LOGOUT</a></li>
   <?php
   	
   	}
   
   ?>
  
  </ul>
</div>
</header>

<div class="line-content">
	<div style="width: 100%; height: 20px; border-bottom: 1px solid black; text-align: center">
  	<span style="font-size: 40px; background-color: white; padding: 0 10px;">
    CONFIRM RESERVATION
  	</span>
	</div>
</div>

<div id="contact-container">
  <!--<h1>&bull; Keep in Touch &bull;</h1>
  <div class="underline"> 
  </div> -->
 
  <div class="icon_wrapper">
   
	
<h4>Astraea Guest House<br/> </h4>
<h5>653-2083 / 09225651905</h5>
<h5>astraeaguesthouse@yahoo.com</h5>
  </div>

<?php
use PHPMailer\PHPMailer\PHPMailer;

if(isset($_GET["id"])){
    include("php_connect.php");
    
    $id = $_GET["id"];
    $sql = "UPDATE `reservation` SET `Status`='PENDING' WHERE ResCode='$id'";
    $res = mysqli_query($conn, $sql);
    ?>
    
    	<div style="width: 70%; margin: auto; margin-top:150px; margin-bottom:150px">
    	    	<center><h3 style=" color: #474544;
  font-size: 20px;
  font-weight: 600;
  text-align: center;
  text-transform: uppercase;">Reservation successfully confirmed!</h3></center><br>
    	    	<center><h5>Please check your email for the Reservation Slip.</h5> <h5>Thank you for patronizing Astraea Guest House.</h5></center>
    	</div>

<?php

        //send email that will redirect to the printing page of the reservation slip  
        $em = "SELECT * FROM reservation JOIN client ON reservation.ClientID=client.ClientID WHERE ResCode='$id'";
        $emres = mysqli_query($conn, $em);
        $emrow = mysqli_fetch_array($emres);
        $email = $emrow["EmailAddress"];


        //email the customer --- working
		// the message
		$message = "Please click the link to print your Reservation Slip: http://astraeaguesthouse.com/front-assets/pages/email.php?id=$id";
		
		$email ='themiracles21@gmail.com';
        
	    // send email
        // PHPMailer Object
        try{
		require '../../vendor/autoload.php';
        $mail = new PHPMailer;
        
        //From email address and name
        $mail->From = "astraeaguesthouse@gmail.com";
        $mail->FromName = "Astraea Guest House";

        //To address and name
        $mail->addAddress($email, 'To our client');
        //$mail->addAddress($email); //Recipient name is optional

        //Address to which recipient will reply
        $mail->addReplyTo("astraea@yahoo.com", "Reply");

        //Send HTML or Plain Text email
        $mail->isHTML(true);

        $mail->Subject = "Confirm Reservation";
        $mail->Body = $message;
        $mail->send();
        echo $email;
        }catch (phpmailerException $e){
            echo 'Error.<br>'.$e;
        }
        
        //email the customer --- working end --

}

?>
   
</div><!-- // End #container -->

<footer>
    <div class="copyright">
        Copyright <i class="fa fa-copyright"></i>  2019 Astraea Guest House. All Rights Reserved
    </div>
</footer>

			
</body>

</html>