<!DOCTYPE html>
<html>
	<head>
		<title>Astraea Guest House | Submit Proof of Payment</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- FONTS -->
        <link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css">

         <style type="text/css">
           @import url(https://fonts.googleapis.com/css?family=Montserrat:400,700);
         </style> 
         <link rel="icon" href="../img/favicos.ico">

    <!-- HEADER AND NAVIGATION-->
        <link rel="stylesheet" type="text/css" href="../css/style.css"/>
        <link rel="stylesheet" href="../css/navstyle.css">

           <script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
           <script src="../js/navstyle.js"></script>

    <!-- CONTACT -->
        <link rel="stylesheet" type="text/css" href="../css/modify.css"/>

	<!-- SWAL -->
	<script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">


		<link rel="stylesheet" type="text/css" href="../css/footer.css"/>

<!-- NOT SURE KUNG SAAN TO -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cdn.jsdelivr.net/jquery.slick/1.5.0/slick.min.js'></script>

		
	</head>

<body>
		
<header>

  <img class="logo" src="../img/a_logo.png" width="70%" height="auto" style="max-width:230px; "/>
   

<div id='cssmenu'>
  <ul>
    <li><a href='../../index.php'>HOME</a></li>
    <li><a href='rooms-index.php'>ROOMS & RATES</a></li>
    <li><a href='gallery.php'>GALLERY</a></li>
    <li class='active'><a href='#'>RESERVATION</a>
      <ul>
        <?php
          //Copy this block of code IZA:
          session_start();
          if(isset($_SESSION["res_in"])){
          ?>
          
          
         <li><a href='reserve.php'>BOOK YOUR STAY</a>
         </li>
         
         <?php
         }
         //end of block of code
         ?>
        <li><a href='modify.php'>MODIFY RESERVATION</a></li>
        <li><a href='submitproof.php'>SUBMIT PROOF OF PAYMENT</a> </li>
      </ul>
   </li>
    <li><a href='contact.php'>CONTACT US</a></li>
   <?php
   	if(!isset($_SESSION['guest_id'])) {
   ?>
   		<li><a href='login.php'>LOGIN</a></li>
   <?php
   	} else {
   ?>
   		<li><a href='logout.php'>LOGOUT</a></li>
   <?php
   	
   	}
   
   ?>
    
  </ul>
</div>
</header>

<div class="line-content">
	<div style="width: 100%; height: 20px; border-bottom: 1px solid black; text-align: center">
  	<span style="font-size: 40px; background-color: white; padding: 0 10px;">
     MODIFY
  	</span>
	</div>
</div>

<div id="contact-container">
  <!--<h1>&bull; Keep in Touch &bull;</h1>
  <div class="underline"> 
  </div> -->
 
 <?php
	if(isset($_GET["message"])){
	?>
		<script>
			swal("Error", "Booking code doesn't exist or payment is not yet settled.", "error");
			history.pushState(null, '', '/front-assets/pages/modify.php');
		</script>
	<?php
	}
	
	    
        if(isset($_SESSION["bookCode"])){
	 	    
	 	    include("php_connect.php");
	 	    //query in out guest from bookCode
	 	    $code = $_SESSION["bookCode"];
	 	    $sqlcode = "SELECT * FROM reservation WHERE ResCode='$code'";
	 	    $rescode = mysqli_query($conn, $sqlcode);
	 	    $rowcode = mysqli_fetch_array($rescode);
	 	    $incode = $rowcode["CheckinDate"];
	 	    $outcode = $rowcode["CheckoutDate"];
	 	    $guestcode = $rowcode["Guests"];
	 	    
	 	    ?>       
	 	     
	 	 	<script>
			swal("Reservation", "You can now modify your booking.", "success");
		</script>
		
		<form action="reserve_sess.php" method="post">
		    
		    
		    <div class="col-lg-12" style="height:300px">
				<center><table style="width:70%">
				<tr>
				<td style="width:60%"><h2 style="font-size: 20px">Check-in Date: </h2></td>
				<td><h2 style="font-size: 20px; font-weight:normal;"> <input id="txtDate" type="date" name="in" value="<?php echo $incode; ?>" onchange="updDate()"  required/></h2></td>	
				</tr>
				<tr>
				<td><h2 style="font-size: 20px">Check-out Date: </h2></td>
				<td><h2 style="font-size: 20px; font-weight:normal;"> <input id="txtDateOut" type="date" name="out" value="<?php echo $outcode; ?>" required/></h2></td>	
				</tr>
				<tr>
				    <?php
			    
			    //get max from DB
			    $sqlset = "SELECT `MaxGuest` FROM `settings` WHERE SettingsID=1";
			    $resset = mysqli_query($conn, $sqlset);
			    $rowset = mysqli_fetch_array($resset);
			    ?>
				<td><h2 style="font-size: 20px">Guest: </h2></td>
				<td><h2 style="font-size: 20px; font-weight:normal;"> <input  type="number" name="guest" min="1" max="<?php echo $rowset["MaxGuest"]; ?>"  value="<?php echo $guestcode; ?>" required></h2></td>	
				</tr>
				</table><br>
				<button class="searchbtn" style="background-color:#222222; color: white; width: 160px; height: 50px; font-size:15px;" type="submit">SEARCH</button>
				</center>
					</div>
		    
		    
         
         
         </form>
			<!-- <div class="kids">
            <input  type="number"  value="0" name="Kids" min="0" max="6">       
			</div>-->
<!--<div class="book">-->
	 	     
	 	    <?php
	 	    }
	 	    ?>
	 	    
 

   
</div><!-- // End #container -->



<footer style="margin-top:100px">

    <div class="copyright">
        Copyright <i class="fa fa-copyright"></i>  2018 Astraea Guest House. All Rights Reserved
    </div>
</footer>

			
</body>

</html>
<script>

Date.prototype.addDays = function(days) {
  var dat = new Date(this.valueOf());
  dat.setDate(dat.getDate() + days);
  return dat;
}

$(function(){
    var dtToday = new Date();
    dtToday = dtToday.addDays(3);
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + (day);
	$('#txtDate').attr('min', maxDate);
	$('#txtDate').val(maxDate);
	
	var inDate = $("#txtDate").val();
	var inDate_ = new Date(inDate);
	var inDatex = inDate_.addDays(1);
    var month_ = inDatex.getMonth() + 1;
    var day_ = inDatex.getDate();
    var year_ = inDatex.getFullYear();
    if(month_ < 10)
        month_ = '0' + month_.toString();
    if(day_ < 10)
        day_ = '0' + day_.toString();
	var tomorrow = year_ + '-' + month_ + '-' + (day_);
	
	$('#txtDateOut').attr('min', tomorrow);
	$('#txtDateOut').val(tomorrow);
});

function updDate(){
	var inDate = $("#txtDate").val();
	var inDate_ = new Date(inDate);
	var inDatex = inDate_.addDays(1);
    var month_ = inDatex.getMonth() + 1;
    var day_ = inDatex.getDate();
    var year_ = inDatex.getFullYear();
    if(month_ < 10)
        month_ = '0' + month_.toString();
    if(day_ < 10)
        day_ = '0' + day_.toString();
	var tomorrow = year_ + '-' + month_ + '-' + (day_);
	
	$('#txtDateOut').attr('min', tomorrow);
	$('#txtDateOut').val(tomorrow);
}

function date_(){
	var dtToday = new Date();
    dtToday = dtToday.addDays(3);
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;
    $('#txtDate').val(maxDate);
}

</script>