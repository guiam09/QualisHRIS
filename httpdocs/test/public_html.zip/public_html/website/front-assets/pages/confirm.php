<!DOCTYPE html>
<html>
<head>
	<title>Astraea Guest House  | Confirm Reservation </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- FONTS -->
	<link rel="icon" href="../img/favicos.ico">
	<link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css">


	<style type="text/css">
	@import url(https://fonts.googleapis.com/css?family=Montserrat:400,700);
</style> 

<!-- HEADER AND NAVIGATION-->
<link rel="stylesheet" type="text/css" href="../css/style.css"/>
<link rel="stylesheet" href="../css/navstyle.css">

<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
<script src="../js/navstyle.js"></script>

<!-- CONTACT -->
<link rel="stylesheet" type="text/css" href="../css/contact.css"/>

<!-- CONTACT -->
<link rel="stylesheet" type="text/css" href="../css/map.css"/>

<link rel="stylesheet" type="text/css" href="../css/footer.css"/>

<!-- NOT SURE KUNG SAAN TO -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cdn.jsdelivr.net/jquery.slick/1.5.0/slick.min.js'></script>



<script src="Inputmask-2.x/dist/jquery.inputmask.bundle.min.js"></script>

<!-- SWAL -->
<script src="dist/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">


</head>

<body>

	<header>

		<img class="logo" src="../img/a_logo.png" width="70%" height="auto" style="max-width:230px; "/>


		<div id='cssmenu'>
			<ul>
				<li><a href='../../index.php'>HOME</a></li>
				<li><a href='rooms-index.php'>ROOMS & RATES</a></li>
				<li><a href='gallery.php'>GALLERY</a></li>
				<li class='active'><a href='#'>RESERVATION</a>
					<ul>
						<?php
          //Copy this block of code IZA:
						session_start();
						if(isset($_SESSION["res_in"])){
							?>




							<?php
						}
         //end of block of code
						?>
						<li><a href='modify.php'>MODIFY RESERVATION</a></li>
						<li><a href='submitproof.php'>SUBMIT PROOF OF PAYMENT</a> </li>
					</ul>
				</li>
				<li><a href='contact.php'>CONTACT US</a></li>
				<?php
				if(!isset($_SESSION['guest_id'])) {
					?>
					<li><a href='login.php'>LOGIN</a></li>
					<?php
				} else {
					?>
					<li><a href='logout.php'>LOGOUT</a></li>
					<?php

				}

				?>

			</ul>
		</div>
	</header>

	<div class="line-content">
		<div style="width: 100%; height: 20px; border-bottom: 1px solid black; text-align: center">
			<span style="font-size: 40px; background-color: white; padding: 0 10px;">
				CONFIRM RESERVATION
			</span>
		</div>
	</div>

	<div id="contact-container">
  <!--<h1>&bull; Keep in Touch &bull;</h1>
  <div class="underline"> 
  </div> -->

  <div class="icon_wrapper">


  	<h4>Astraea Guest House<br/> </h4>
  	<h5>0915 403 7988</h5>
  	<h5>amorashome@yahoo.com</h5>
  </div>

  <?php
  if(isset($_GET["success_"])){


  	?>
  	<div style="width: 70%; margin: auto; margin-top:150px; margin-bottom:150px;">
  		<center><h3 style=" color: #474544;
  		font-size: 20px;
  		font-weight: 600;
  		text-align: center;
  		text-transform: uppercase;">A message has been sent to your email address. Please check the email you provided and click the link to confirm your reservation. Thank you!</h3>
  		<h5>Didn't get the email?</h5>
  		<h5>Check your junk mail or spam mail folder.</h5></center>
  	</div>

  	<?php
  }
  elseif(isset($_GET["successx"])){
  	?>

  	<div style="width: 70%; margin: auto; margin-top:150px; margin-bottom:150px">
  		<center><h2>Your updated reservation slip has been sent to your email address. Thank you! </h2></center>
  	</div>

  	<?php
  }
  else{
  	?>



  	<form action="save_reservation.php" method="post" id="contact_form">

  		<?php
  		if(isset($_SESSION["indate"])){
  			include("php_connect.php");
  			$in = $_SESSION["indate"];
  			$out = $_SESSION["outdate"];
  			$number = $_SESSION["guest"];
  			$perroom = $_SESSION["numperroom"];
  			$days = round((strtotime($out) - strtotime($in))/60/60/24);
  			?>
  			<div style="width: 90%; margin: auto;">
  				<br>
  				<center><h1>Reservation Summary</h1></center>
  				<br>
  				<h4>Booking Details</h4>
  				<br>
  				<table style="width:100%">
  					<tr>
  						<td style="width:40%; font-size: 18px;">Check-in Date: </td>
  						<td style="width:60%; font-size: 18px;"><?php echo $in; ?></td>
  					</tr>
  					<tr>
  						<td style="width:30%; font-size: 18px;">Check-out Date: </td>
  						<td style="width:70%; font-size: 18px;"><?php echo $out; ?></td>
  					</tr>
  					<tr>
  						<td style="width:30%; font-size: 18px;">Days: </td>
  						<td style="width:70%; font-size: 18px;"><?php echo $days." day(s)"; ?></td>
  					</tr>
  					<tr>
  						<td style="width:30%; font-size: 18px;">Guest(s): </td>
  						<td style="width:70%; font-size: 18px;"><?php echo $number." pax"; ?></td>
  					</tr>
  					<tr>
  						<td style="width:30%; font-size: 18px;">&nbsp;</td>
  						<td style="width:70%; font-size: 18px;">&nbsp;</td>
  					</tr>
  					<tr>
  						<td style="width:30%; font-size: 18px; font-weight: bold">Room(s): </td>
  						<td style="width:70%; font-size: 18px;">
  							&nbsp;
  						</td>
  					</tr>
  					<tr>
  						<td style="width:30%; font-size: 18px;">&nbsp;</td>
  						<td style="width:70%; font-size: 18px;"></td>
  					</tr>
  					<tr>

  						<td colspan=2>
  							<table style="width:100%">
  								<tr>
  									<td style="width:20%; font-size: 18px;">Room Type</td>
  									<td style="width:20%; font-size: 18px;">Room Price</td>
  									<td style="width:20%; font-size: 18px;">Quantity</td>
  									<td style="width:20%; font-size: 18px;">Max. Guests</td>
  									<td style="width:20%; font-size: 18px;">Amount</td>
  								</tr>
  								<?php
  								$perroom = rtrim($perroom, ';');
  								$arrayvar = explode(";",$perroom);
  								$totalsub = 0;
  								$additional = 0;
  								$totalcap = 0;
  								$remguest = $number;
  								$matt = 0;
  								foreach($arrayvar as $a){
  									$break = explode(",", $a);
  									$quantity = $break[0];
  									$roomnum = $break[1];
  									if($quantity != 0){
										//get room price
  										$price = "SELECT * FROM room_type WHERE RoomTypeID=$roomnum";
  										$res = mysqli_query($conn, $price);
  										$row = mysqli_fetch_array($res);
  										$roomtype = $row["Description"];
  										$rprice = $row["Price"];
  										$sub = $rprice * $days * $quantity;
  										$cap = $row["Capacity"];
  										$totalcap += $cap * $quantity;
  										$matt += 2 * $quantity;
  										?>
  										<tr>
  											<td style="width:20%; font-size: 18px;"><?php echo $roomtype; ?></td>
  											<td style="width:20%; font-size: 18px;"><?php echo "Php ".number_format($rprice, 2); ?></td>
  											<td style="width:20%; font-size: 18px;"><?php echo $quantity; ?></td>
  											<td style="width:20%; font-size: 18px;"><?php echo $cap * $quantity; ?></td>
  											<td style="width:20%; font-size: 18px;"><?php echo "Php ".number_format($sub, 2); ?></td>
  										</tr>
  										<?php
  										$totalsub += $sub;
  									}
  								}
  								?>
  							</table>
  						</td>
  					</tr>	
  					<tr>
  						<td style="width:30%; font-size: 18px;">&nbsp;</td>
  						<td style="width:70%; font-size: 18px;">&nbsp;</td>
  					</tr>
  					<?php   
  					$total_ = $totalsub + $additional;
  					$ex = $number - $totalcap;
  					if($matt < $ex){
  						?>
  						<script>
  							swal({
  								title: "Room Cap Validation!",
  								text: "We can't accommodate the given number of guests even with the inclusion of 2 mattresses per room selected. <?php echo $ex-$matt; ?> excess guests.",
  								type: "warning",
  								confirmButtonClass: "btn-danger",
  								confirmButtonText: "Ok!",
  								closeOnConfirm: false
  							}, function() {
  								window.location = "reserve.php";
  							});
  						</script>
  						<?php
  					}
  					if($ex < 0){
  						$ex = 0;
  					}
  					if($ex > 0){
							    //get price of mattress from settings
  						$genmat = "SELECT * FROM settings WHERE SettingsID=1";
  						$resmat = mysqli_query($conn, $genmat);
  						$rowmat = mysqli_fetch_array($resmat);
  						$prmat = $rowmat["MattressPrice"];
  						?>
  						<tr>
  							<td style="width:30%; font-size: 18px; font-weight: bold">Note for Extra Persons: </td>
  							<td style="width:70%; font-size: 18px;">
  								&nbsp;
  							</td>
  						</tr>	
  						<tr>
  							<td style="width:30%; font-size: 18px;">&nbsp;</td>
  							<td style="width:70%; font-size: 18px;">&nbsp;</td>
  						</tr>
  						<tr>
  							<td style="width:50%; font-size: 18px;">Extra Persons: </td>
  							<td style="width:50%; font-size: 18px;"><?php echo $ex." pax"; ?></td>
  						</tr>
  						<tr>
  							<td style="width:50%; font-size: 18px;">Extra Mattress (Php <?php echo number_format($prmat, 2); ?> each): </td>
  							<td style="width:50%; font-size: 18px;">
  								<input type="number" name="mat" style="width:50%; border:0px" id="mat" min="1" max="100" readonly value="<?php echo $ex; ?>">
  							</td>
  						</tr>
  						<tr>
  							<td style="width:50%; font-size: 18px;">Additional Charges:</td>
  							<td style="width:50%; font-size: 18px;">Php&nbsp; 
  								<input type="text" style="border:0px; width:50%" id="add" readonly value="<?php echo str_replace(",","",number_format($ex * $prmat, 2)); ?>">
  							</td>
  						</tr>
  						<script>
  							$("#mat").on('keyup', function () {
  								var ch = parseFloat($("#mat").val());

  								if(isNaN(ch)){
  									ch = 0;
  								}
  								if(ch <= 1){
  									ch = 1;
  								}
						        //var g = parseFloat($("#add").val());
						        var totalch = ch * <?php echo $prmat; ?>;
						        var vat = parseFloat((totalch + <?php echo $total_; ?>)/1.12).toFixed(2);
						        var vatx = parseFloat(((totalch + <?php echo $total_; ?>)/1.12)*0.12).toFixed(2);
						        var tot = parseFloat(totalch + <?php echo $total_; ?>).toFixed(2);
						        var t = parseFloat($("#totalz").val());
						        var newbal = parseFloat(tot - t).toFixed(2);
						        
						        $("#add").val(totalch);
						        $("#vat").val(vat);
						        $("#vatx").val(vatx);
						        $("#tot").val(tot);
						        $("#newbal").val(newbal);
						    });
						</script>
						<?php
					}
					?>
					<tr>
						<td style="width:30%; font-size: 18px;">&nbsp;</td>
						<td style="width:70%; font-size: 18px;">&nbsp;</td>
					</tr><tr>
						<td style="width:30%; font-size: 18px; font-weight:bold">Payment Details</td>
						<td style="width:70%; font-size: 18px;">&nbsp;</td>
					</tr>
					<tr>
						<td style="width:30%; font-size: 18px;">&nbsp;</td>
						<td style="width:70%; font-size: 18px;">&nbsp;</td>
					</tr>
					<tr>
						<td style="width:50%; font-size: 18px;">Total Room Fee: </td>
						<td style="width:50%; font-size: 18px;"><?php echo "Php ".number_format($totalsub, 2); ?></td>
					</tr>
					<tr>
						<td style="width:50%; font-size: 18px;">Vatable Amount:</td>
						<td style="width:50%; font-size: 18px;">
							Php&nbsp;<input type="number" style="border:0px; width:50%" id="vat" readonly value="<?php 
							echo str_replace(",", "", number_format($totalsub - $totalsub * 0.12, 2)); ?>"></td>
						</tr>
						<tr>
							<td style="width:50%; font-size: 18px;">VAT (12%):</td>
							<td style="width:50%; font-size: 18px;">
								Php&nbsp;<input type="number" style="border:0px; width:50%" id="vatx" readonly value="<?php 
								echo str_replace(",", "", number_format($totalsub * 0.12, 2)); ?>">
							</td>
						</tr>
						
						<tr>
							<td style="width:50%; font-size: 18px;">Total Amount:</td>
							<td style="width:50%; font-size: 18px; font-weight: bold" id="total">
								Php&nbsp;<input type="number" name="total" style="border:0px; width:50%" id="tot" readonly value="<?php 
								echo str_replace(",", "", number_format($totalsub, 2)); ?>">
							</td>
						</tr>
						
						<?php
						//condition here
						if(isset($_SESSION["bookCode"])){

							$rescode = $_SESSION["bookCode"];
							$sqlcode = "SELECT * FROM reservation WHERE ResCode='$rescode'";
							$rescodex = mysqli_query($conn, $sqlcode);
							$rowcode = mysqli_fetch_array($rescodex);
							$paid = $rowcode["DownpaymentPaid"];
							$total_ -= $paid;
							if($total_ < 0){
								$total_ = 0;
							}
							?>

							<tr>
								<td style="width:50%; font-size: 18px;">Downpayment Paid:</td>
								<td style="width:50%; font-size: 18px;" id="total">Php <?php echo number_format($paid, 2); ?>
								<input type="number" hidden id="totalz" value="<?php echo $paid; ?>">
							</td>
						</tr>
						
						
						<tr>
							<td style="width:50%; font-size: 18px;">New Balance:</td>
							<td style="width:50%; font-size: 18px; font-weight: bold" id="total">
								&nbsp;<input type="number" name="newbal" style="border:0px; width:50%" id="newbal" readonly value="<?php 
								echo str_replace(",", "", number_format(($total_ + $prmat), 2)); ?>">
							</td>
						</tr>

						<?php
					}
					else{
						?>
						
						<tr>
							<td style="width:30%; font-size: 18px;">Deadline of Downpayment: </td>
							
							<?php
								//get maxreserve days from settings

							$settings = "SELECT * FROM settings WHERE SettingsID=1";
							$resset = mysqli_query($conn, $settings);
							$rowset = mysqli_fetch_array($resset);
							$resday = $rowset["MaxReservationDays"];
							$NewDate=Date('F j, Y', strtotime("+$resday days"));
							?>
							
							<td style="width:70%; font-size: 18px; font-weight: bold"><?php echo $NewDate; ?></td>
						</tr>
						
						
						<?php
					}
					?>


				</table>
				<br><br><br>
				

			</div>
			<?php
		}
		?>


		<?php
		if(isset($_SESSION["bookCode"])){
			?>
			<center>    
				<input type="checkbox" required> I have read and understood the terms and conditons
				<br><br><br>
				<input type="submit" value="Modify Booking" name="submitMod" id="form_button" />
				<input type="text"maxlength="50" name="total" hidden required value="<?php echo $total_; ?>">
			</center>
			<?php  
		}
		else{

			if (session_status() == PHP_SESSION_NONE) {
				session_start();
			}

			?>


			<p> Required Field is with * </p>

			<div class="name">
				<label for="name"></label>
				<p> Name (First and Last Name) * </p>
				<input type="text" maxlength="50" name="name" id="name_input" title="Name should contain atleast your first name and last name." required value="<?php if(isset($_SESSION['name_input'])){ echo $_SESSION['name_input']; } ?>" >
			</div>
			<div class="telephone">
				<label for="name"></label>
				<p> Contact Number *</p>
				<input type="text" onkeypress = "isInputNumber(event)" placeholder="09XXXXXXXXX" name="number" maxlength="11" title="Follow the format: 09XXXXXXXXX." id="telephone_input" required value="<?php if(isset($_SESSION['number'])){ echo $_SESSION['number']; } ?>" >
				<script>
					function isInputNumber(evt) {
						var ch = String.fromCharCode(evt.which);
						if(!(/[0-9]/.test(ch))) {
							evt.preventDefault();
						}
					}
				</script>
			</div>
			<div class="email">
				<p> <br></br> </p>	
				<p> <br></br> </p>
				<p> <br></br> </p>
				<p> Email Address * </p>
				<label for="email"></label>
				<input type="email" placeholder= "ABCD@gmail.com" maxlength="50" name="email" id="email_input" required value="<?php if(isset($_SESSION['email_input'])){ echo $_SESSION['email_input']; } ?>" >
			</div>

			<div class="message">
				<label for="message"></label>
				<p> Address *</p>
				<textarea name="address" placeholder="Kaykulot Road, Sungay East,Tagaytay City, Cavite" id="message_input" maxlength="65535" cols="30" rows="5" required ><?php if(isset($_SESSION['address'])){ echo $_SESSION['address']; } ?></textarea>
			</div>
			<div class="submit">
				<input type="submit" value="Confirm Booking" name="submit" id="form_button" />
			</div>

			<?php
		}
		?>
	</form><!-- // End form -->

	<?php
}
?>

</div><!-- // End #container -->

<footer>
	<div class="copyright">
		Copyright <i class="fa fa-copyright"></i>  2019 Astraea Guest House. All Rights Reserved
	</div>
</footer>


</body>

</html>
<script>
	$( document ).ready(function() {
		$( "#name_input" ).keypress(function(e) {
			var key = e.keyCode;
			if (key >= 48 && key <= 57) {
				e.preventDefault();
			}
		});
	});
</script>