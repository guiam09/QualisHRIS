<?php
    $email ='themiracles21@gmail.com';
    require_once "phpmailer/PHPMailerAutoload.php";
    try{
	    // send email
        //PHPMailer Object
        $mail = new PHPMailer;
    
        //From email address and name
        $mail->From = "astraeaguesthouse@gmail.com";
        $mail->FromName = "Astraea Guest House";

        //To address and name
        $mail->addAddress($email, $name);
        //$mail->addAddress($email); //Recipient name is optional

        //Address to which recipient will reply
        $mail->addReplyTo("astraea@yahoo.com", "Reply");

        //Send HTML or Plain Text email
        $mail->isHTML(true);

        $mail->Subject = "Confirm Reservation";
        $mail->Body = "TRIAL 123";
        $mail->send();
        echo 'Success! Please click <a style="color:red;" onclick="window.close()">here</a> to close this window.';
        }catch (phpmailerException $e){
            echo 'Error.<br>'.$e;
        }
?>