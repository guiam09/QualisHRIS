<?php
	session_start();
	unset($_SESSION['guest_id']);
	unset($_SESSION['username']);
	unset($_SESSION['name']);
	unset($_SESSION['email']);
	unset($_SESSION['address']);
	unset($_SESSION['number']);
	
	header("Location:../../index.php");
?>