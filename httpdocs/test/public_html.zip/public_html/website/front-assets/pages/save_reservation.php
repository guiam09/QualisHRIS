s<?php
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;
    require_once "phpmailer/PHPMailerAutoload.php";
    
	if(isset($_POST["submit"])){
		include("php_connect.php");
		session_start();
		date_default_timezone_set("Asia/Manila");
		$today = date("Y-m-d");
		$todaytime = date("H:i");
		$year = date("Y");
		$in = date_create($_SESSION["indate"]);
		$in_x = date_format($in, "d");
		$in_ = date_format($in, "Y-m-d");
		$out = date_create($_SESSION["outdate"]);
		$out_ = date_format($out, "Y-m-d");
		$out_x = date_format($out, "d");
	
		do {
			$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$charactersLength = strlen($characters);
			$randomString = '';
			for ($i = 0; $i < 5; $i++) {
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
    
			//for reservation code (year.in.out.random(5)
			$rescode = $year.$in_x.$out_x.$randomString;
		
			$chkcode = "SELECT * FROM reservation WHERE ResCode='$rescode'";
			$reschkcode = mysqli_query($conn, $chkcode);
			$numcode = mysqli_num_rows($reschkcode);
	
		} while($numcode != 0);
	
		$guest = $_SESSION["guest"];
		$total = $_POST["total"];
	
	
		if(isset($_POST["mat"])){
			$mat = $_POST["mat"];
		} else {
			$mat = 0;
		}
	
		//insert to client tbl first
		$clname = $_POST["name"];
		$clemail = $_POST["email"];
		$claddress = $_POST["address"];
		$clnumber = $_POST["number"];
	
		if(!isset($_SESSION['guest_id'])){
			$username = mb_substr($clname, 0, 2);
			$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$charactersLength = strlen($characters);
			$randomString2 = '';
			for ($i = 0; $i < 5; $i++) {
				$randomString2 .= $characters[rand(0, $charactersLength - 1)];
			}
			$username = (mb_substr($clname, 0, 2)).$randomString2;
			
			$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
			$charactersLength = strlen($characters);
			$pword = '';
			for ($i = 0; $i < 10; $i++) {
				$pword .= $characters[rand(0, $charactersLength - 1)];
			}
		
			$insguest_account = "INSERT INTO `guest_account`(`guest_id`, `username`, `password`, `name`, `email`, `address`, `number`) VALUES ('','$username','$pword','$clname','$clemail','$claddress','$clnumber')";
			$makeguest_acc = mysqli_query($conn,$insguest_account);
			
			//get last guest_id
			$max_id = "SELECT MAX(guest_id) as max_id FROM `guest_account`";
			$max_id2 = mysqli_query($conn,$max_id);
			$max_id3 = mysqli_fetch_array($max_id2);
			
			$new_guestId = $max_id3['max_id'];
			
			$insclient = "INSERT INTO `client`(`ClientID`, `Name`, `EmailAddress`, `Address`, `ContactNumber`, `Status`, `Deleted`,`client_account_id`) VALUES ('', '$clname', '$clemail', '$claddress', '$clnumber', 'Active', 'No',$new_guestId)";
			$rescl = mysqli_query($conn, $insclient);
		
			//get last clientID
			$selcl = "SELECT * FROM client ORDER BY ClientID DESC";
			$rescl = mysqli_query($conn, $selcl);
			$rowcl = mysqli_fetch_array($rescl);
			
			$client = $rowcl["ClientID"];
		} else {
		
			$guestId = $_SESSION['guest_id'];
			
			$insclient = "INSERT INTO `client`(`ClientID`, `Name`, `EmailAddress`, `Address`, `ContactNumber`, `Status`, `Deleted`,`client_account_id`) VALUES ('', '$clname', '$clemail', '$claddress', '$clnumber', 'Active', 'No',$guestId )";
			$rescl = mysqli_query($conn, $insclient);
			
			//get last clientID
			
			$selcl = "SELECT * FROM client ORDER BY ClientID DESC";
			$rescl = mysqli_query($conn, $selcl);
			$rowcl = mysqli_fetch_array($rescl);
			
			$client = $rowcl["ClientID"];
		}
	
		//get maxreserve days from settings
		$settings = "SELECT * FROM settings WHERE SettingsID=1";
		$resset = mysqli_query($conn, $settings);
		$rowset = mysqli_fetch_array($resset);
		$resday = $rowset["MaxReservationDays"];
									
		$expdate = date("Y-m-d", strtotime("$today +$resday days" ));
		
		$perroom = $_SESSION["numperroom"];
		$save = "INSERT INTO `reservation`(`ReservationID`, ResCode, `ReservationDate`, `CheckinDate`, `CheckoutDate`, `Guests`, `ClientID`, `TotalBill`, `Status`, `ExpDate`, `Mattress`, `ReservationTime`) VALUES ('','$rescode', '$today','$in_','$out_',$guest,'$client',$total,'WAITING', '$expdate', $mat, '$todaytime')";
		$res = mysqli_query($conn, $save);	
		if($res){
			//per room
			//get reservation id
			$get = "SELECT * FROM reservation ORDER BY ReservationID DESC";
			$resget = mysqli_query($conn, $get);
			$rowget = mysqli_fetch_array($resget);
			$resid = $rowget["ReservationID"];
			
			$perroom = rtrim($perroom, ';');
			$arrayvar = explode(";",$perroom);
			foreach($arrayvar as $a){
				$break = explode(",", $a);
				$quantity = $break[0];
				$roomnum = $break[1];
				if($quantity != 0){
					//get room number from the roomtype given
					$getrm = "SELECT * FROM room WHERE RoomTypeID=$roomnum";
					$resnum = mysqli_query($conn, $getrm);
					$rownum = mysqli_fetch_array($resnum);
					$room = $rownum["RoomNumber"];
					for($i = 0; $i < $quantity; $i++){
						//query for insert here
						$ins = "INSERT INTO `room_reservation`(`RoomReservationID`, `RoomNumber`, `ReservationID`) VALUES ('','$room',$resid)";
						$resins = mysqli_query($conn, $ins);
					}
				}
			}
		}
		unset($_SESSION["indate"]);
		//email the customer --- working
		// the message
		$msg = "Please click the link to confirm reservation: http://astraeaguesthouse.com/front-assets/pages/confirm_res.php?id=$rescode. Your username is $username and your password is $pword. You can log-in to check your bookings.";
		
		$email ='themiracles21@gmail.com';
        
	    // send email
        // PHPMailer Object
        try{
		require '../../vendor/autoload.php';
        $mail = new PHPMailer;
        
        //From email address and name
        $mail->From = "astraeaguesthouse@gmail.com";
        $mail->FromName = "Astraea Guest House";

        //To address and name
        $mail->addAddress($clemail, $name);
        //$mail->addAddress($email); //Recipient name is optional

        //Address to which recipient will reply
        $mail->addReplyTo("astraea@yahoo.com", "Reply");

        //Send HTML or Plain Text email
        $mail->isHTML(true);

        $mail->Subject = "Confirm Reservation";
        $mail->Body = $msg;
        $mail->send();
        //echo 'Success! Please click <a style="color:red;" onclick="window.close()">here</a> to close this window.';
        echo $clemail;
        }catch (phpmailerException $e){
            echo 'Error.<br>'.$e;
        }
        
        //email the customer --- working end --
    
		
		
		header("location:confirm.php?success_");
		} else	{
			include("php_connect.php");
			session_start();
		   
			$rescode = $_SESSION["bookCode"];
			$sqlcode = "SELECT * FROM reservation JOIN client ON reservation.ClientID=client.ClientID WHERE ResCode='$rescode'";
			$rescodex = mysqli_query($conn, $sqlcode);
			$rowcode = mysqli_fetch_array($rescodex);
								
			$resID = $rowcode["ReservationID"];
		   
			$del = "DELETE FROM room_reservation WHERE ReservationID=$resID";
			$resdel = mysqli_query($conn, $del);
		   
			//update reservation
			date_default_timezone_set("Asia/Manila");
			$today = date("Y-m-d");
			$year = date("Y");
			$in = date_create($_SESSION["indate"]);
			$in_x = date_format($in, "d");
			$in_ = date_format($in, "Y-m-d");
			$out = date_create($_SESSION["outdate"]);
			$out_ = date_format($out, "Y-m-d");
			$out_x = date_format($out, "d");
			$guest = $_SESSION["guest"];
			$total = $_POST["newbal"];
			$perroom = $_SESSION["numperroom"];
			if(isset($_POST["mat"])){
				$mat = $_POST["mat"];
			} else {
				$mat = 0;
			}
		
			$save = "UPDATE `reservation` SET `ReservationDate`='$today',`CheckinDate`='$in_',`CheckoutDate`='$out_',`Guests`=$guest,`RemainingBalance`=$total, `Mattress`=$mat WHERE `ResCode`='$rescode'";
			$res = mysqli_query($conn, $save);	
			if($res) {
				$perroom = rtrim($perroom, ';');
				$arrayvar = explode(";",$perroom);
				foreach($arrayvar as $a){
					$break = explode(",", $a);
					$quantity = $break[0];
					$roomnum = $break[1];
					if($quantity != 0){
						//get room number from the roomtype given
						$getrm = "SELECT * FROM room WHERE RoomTypeID=$roomnum";
						$resnum = mysqli_query($conn, $getrm);
						$rownum = mysqli_fetch_array($resnum);
						$room = $rownum["RoomNumber"];
						for($i = 0; $i < $quantity; $i++){
							//query for insert here
							$ins = "INSERT INTO `room_reservation`(`RoomReservationID`, `RoomNumber`, `ReservationID`) VALUES ('','$room',$resID)";
							$resins = mysqli_query($conn, $ins);
						}
					}
				}
			}
			
			unset($_SESSION["indate"]);
			unset($_SESSION["bookCode"]);
		
			
			//email the customer --- working
		    // the message
		    $msg = "Please click the link to print your updated Reservation Slip: http://astraeaguesthouse.com/front-assets/pages/email.php?id=$rescode";
		
		    $email ='themiracles21@gmail.com';
        
	        // send email
            // PHPMailer Object
            try{
		    require '../../vendor/autoload.php';
            $mail = new PHPMailer;
        
            //From email address and name
            $mail->From = "astraeaguesthouse@gmail.com";
            $mail->FromName = "Astraea Guest House";

            //To address and name
            $mail->addAddress($email, 'To our client');
            //$mail->addAddress($email); //Recipient name is optional
    
            //Address to which recipient will reply
            $mail->addReplyTo("astraea@yahoo.com", "Reply");

            //Send HTML or Plain Text email
            $mail->isHTML(true);

            $mail->Subject = "Confirm Reservation";
            $mail->Body = $msg;
            $mail->send();
            echo 'Success! Please click <a style="color:red;" onclick="window.close    ()">here</a> to close this window.';
            
			//header("location:confirm.php?successx");
			
            echo $clemail;
            }catch (phpmailerException $e){
                echo 'Error.<br>'.$e;
            }
            
        
            //email the customer --- working end --
			
			
			
		}
?>
