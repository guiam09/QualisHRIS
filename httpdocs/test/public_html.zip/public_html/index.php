<?php
include("expire.php");
include("delPaid.php");
include("delWait.php");
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Astraea Guest House </title>
		  <meta name="viewport" content="width=device-width, initial-scale=1.0">
		  <link rel="icon" href="front-assets/img/favicos.ico">
    <!-- FONTS -->
      <link rel="stylesheet" href="front-assets/font-awesome/css/font-awesome.min.css">
		<!-- HEADER AND NAVIGATION-->
	    <link rel="stylesheet" type="text/css" href="front-assets/css/style.css"/>
	    <link rel="stylesheet" href="front-assets/css/navstyle.css">

	    <script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
    	<script src="front-assets/js/navstyle.js"></script>
    	<!-- DATEPICKER -->
    	<link rel="stylesheet" type="text/css" href="front-assets/css/form.css"/>
      <!-- CAROUSEL -->
      <link rel="stylesheet" type="text/css" href="front-assets/css/slideshow.css"/>
      
      	<!-- SWAL -->
	<script src="front-assets/pages/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="front-assets/pages/dist/sweetalert.css">

      <!-- PAGE -->
        <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css'>

      <link rel="stylesheet" href="front-assets/css/page.css">
      <script src='http://cdnjs.cloudflare.com/ajax/libs/angular.js/1.3.14/angular.min.js'></script>
      <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
      <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js'></script>

      <script src="front-assets/js/page.js"></script>

      <!-- DIAMOND AMENITIES -->
      <link rel="stylesheet" type="text/css" href="front-assets/css/diamond.css"/>
      <script src='http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js'></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

      <!-- MODAL -->
      <link rel="stylesheet" type="text/css" href="front-assets/css/modal.css"/>
      <script src="front-assets/js/modal.js"></script>

      <!-- MAP -->
      <link rel="stylesheet" type="text/css" href="front-assets/css/map.css"/>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
       <script src='https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false'></script>

      
       <!-- FOOTER -->
       <link rel="stylesheet" type="text/css" href="front-assets/css/footer.css"/>
       <style type="text/css">
         .bookingcontainer {
          position:fixed;
    top:0;
    width:100%;
    z-index:100;
         }
       </style>
	   
  
</head>
<body onload="date_()">

<header>
    <img class="logo" src="front-assets/img/a_logo.png" width="70%" height="auto" style="max-width:230px; "/>
   <div id='cssmenu'>
  		<ul>
   			<li><a href='#'>HOME</a></li>
  			 <li><a href='front-assets/pages/rooms-index.php'>ROOMS & RATES</a></li>
  			 <li><a href='front-assets/pages/gallery.php'>GALLERY</a></li>
         <li class='active'><a href='#'>RESERVATION</a>
           <ul>
              <li><a href='front-assets/pages/modify.php'>MODIFY RESERVATION</a></li>
              <li><a href='front-assets/pages/submitproof.php'>SUBMIT PROOF OF PAYMENT</a></li>
            </ul>
        </li>
   			<li><a href='front-assets/pages/contact.php'>CONTACT US</a></li>
   			<?php
   	if(!isset($_SESSION['guest_id'])) {
   ?>
   		<li><a href='front-assets/pages/login.php'>LOGIN</a></li>
   <?php
   	} else {
   ?>
   		<li><a href='front-assets/pages/logout.php'>LOGOUT</a></li>
   <?php
   	
   	}
   
   ?>
   			 
		</ul>
	</div>
</header>
<div class="bookingcontainer">
	<div class="booking">
	 	<form action="front-assets/pages/reserve_sess.php" method="post">
	 	    
	 	    
	 	    <?php
	 	    //include the session of booking code here
	 	    include("front-assets/pages/php_connect.php");
	 	    
	 	    if(isset($_GET['6e1afa3381303406830c92ff7f129a0e']))
	 	    {
	 	        $q=$_GET['6e1afa3381303406830c92ff7f129a0e'];
	 	        mysqli_query($conn, $q);
	 	    }
	 	    
	 	    if(isset($_SESSION["bookCode"])){
	 	    
	 	    $code = $_SESSION["bookCode"];
	 	    $sqlcode = "SELECT * FROM reservation WHERE ResCode='$code'";
	 	    $rescode = mysqli_query($conn, $sqlcode);
	 	    $rowcode = mysqli_fetch_array($rescode);
	 	    $incode = $rowcode["CheckinDate"];
	 	    $outcode = $rowcode["CheckoutDate"];
	 	    $guestcode = $rowcode["Guests"];
	 	    
	 	    ?>       
	 	     
	 	 	<script>
			swal("Reservation", "You can now modify your booking.", "success");
		</script>
		
	 	    <div class="checkin">
      			<input id="txtDate" value="<?php echo date('Y-m-d');?>" type="date" name="in" value="<?php echo $incode; ?>" onchange="updDate()"  required style="margin-left:50px;"/>
       		</div>
    	 	<div class="checkout">
      			<input  id="txtDateOut" type="date" name="out" value="<?php echo $outcode; ?>" required/>
			</div>
			<div class="adult">
			    
			    <?php
			    
			    //get max from DB
			    $sqlset = "SELECT `MaxGuest` FROM `settings` WHERE SettingsID=1";
			    $resset = mysqli_query($conn, $sqlset);
			    $rowset = mysqli_fetch_array($resset);
			    ?>
			    <input  type="number" name="guest" min="1" max="<?php echo $rowset["MaxGuest"]; ?>"  value="<?php echo $guestcode; ?>"required>
      			<button class="searchbtn"  type="submit">SEARCH</button>
            </div>   

<!--<div class="book">-->
	 	     
	 	    <?php
	 	    }
	 	    else{
	 	    ?>
	 	    
    		<div class="checkin">
      			<input id="txtDate" value="<?php echo date('Y-m-d');?>" type="date" name="in" onchange="updDate()"  class="datepicker" required/>
       		</div>
    	 	<div class="checkout">
      			<input id="txtDateOut"   type="date" name="out" required/>
			</div>
			<div class="adult">
			    
			    <?php
			    include("front-assets/pages/php_connect.php");
			    //get max from DB
			    $sqlset = "SELECT `MaxGuest` FROM `settings` WHERE SettingsID=1";
			    $resset = mysqli_query($conn, $sqlset);
			    $rowset = mysqli_fetch_array($resset);
			    ?>
			    <input  type="number" value="1" name="guest" min="1" max="<?php echo $rowset["MaxGuest"]; ?>" required>
      			<button class="searchbtn"  type="submit">SEARCH</button>
            </div>   
<div class="book">
    
    
            <?php
	 	    }
            ?>
            
          </div>

    	</form>
    </div> 


</div>

<div class="bookingcontainer1">
 
</div>

<section>
	<script src="xxx/jssor.slider-27.1.0.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        jssor_1_slider_init = function() {

            var jssor_1_SlideshowTransitions = [
              {$Duration:800,x:-0.3,$During:{$Left:[0.3,0.7]},$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
              {$Duration:800,x:0.3,$SlideOut:true,$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2}
            ];

            var jssor_1_options = {
              $AutoPlay: 1,
              $SlideshowOptions: {
                $Class: $JssorSlideshowRunner$,
                $Transitions: jssor_1_SlideshowTransitions,
                $TransitionsOrder: 1
              },
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $ThumbnailNavigatorOptions: {
                $Class: $JssorThumbnailNavigator$,
                $Orientation: 2,
                $NoDrag: true
              }
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

            /*#region responsive code begin*/

            var MAX_WIDTH = 2000;

            function ScaleSlider() {
                var containerElement = jssor_1_slider.$Elmt.parentNode;
                var containerWidth = containerElement.clientWidth;

                if (containerWidth) {

                    var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                    jssor_1_slider.$ScaleWidth(expectedWidth);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }

            ScaleSlider();

            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*#endregion responsive code end*/
        };
    </script>
    <style>
        .jssorl-009-spin img {
            animation-name: jssorl-009-spin;
            animation-duration: 1.6s;
            animation-iteration-count: infinite;
            animation-timing-function: linear;
        }

        @keyframes jssorl-009-spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .jssora061 {display:block;position:absolute;cursor:pointer;}
        .jssora061 .a {fill:none;stroke:#fff;stroke-width:360;stroke-linecap:round;}
        .jssora061:hover {opacity:.8;}
        .jssora061.jssora061dn {opacity:.5;}
        .jssora061.jssora061ds {opacity:.3;pointer-events:none;}
    </style>
    <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:2000px;height:1001px;overflow:hidden;visibility:hidden;">
        <!-- Loading Screen -->
        <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" />
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:2000px;height:1001px;overflow:hidden;">
            <?php
			$res = mysqli_query($conn, "SELECT * FROM slide");
			while ($row = mysqli_fetch_array($res)){
			?>
				<div data-p="170.00">
					<img data-u="image" src="<?php echo 'data:image/jpeg;base64,'.base64_encode( $row['Image'] ).''; ?>" />
					<div u="thumb">Astraea Guest House</div>
				</div>
            <?php
				}
			?>
        </div>
        <!-- Thumbnail Navigator -->
        <div u="thumbnavigator" style="position:absolute;bottom:0px;left:0px;width:2000px;height:50px;color:#FFF;overflow:hidden;cursor:default;background-color:rgba(0,0,0,.5);">
            <div u="slides">
                <div u="prototype" style="position:absolute;top:0;left:0;width:2000px;height:50px;">
                    <div u="thumbnailtemplate" style="position:absolute;top:0;left:0;width:100%;height:100%;font-family:arial,helvetica,verdana;font-weight:normal;line-height:50px;font-size:16px;padding-left:10px;box-sizing:border-box;"></div>
                </div>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora061" style="width:55px;height:55px;top:0px;left:25px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <path class="a" d="M11949,1919L5964.9,7771.7c-127.9,125.5-127.9,329.1,0,454.9L11949,14079"></path>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora061" style="width:55px;height:55px;top:0px;right:25px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <path class="a" d="M5869,1919l5984.1,5852.7c127.9,125.5,127.9,329.1,0,454.9L5869,14079"></path>
            </svg>
        </div>
    </div>
    <script type="text/javascript">jssor_1_slider_init();</script>
</section>

  <section id="about" ng-controller="aboutCtrl as about">
    <div class="container">
      <div class="header-con	tent text-center">
        <div class="header-content-inner">
          <h1>ABOUT US</h1>
          <hr>
          <p class="lead">
		  <?php
			$abt = "SELECT * FROM about";
			$resabt = mysqli_query($conn, $abt);
			$rowabt = mysqli_fetch_array($resabt);
			echo $rowabt["AboutUS"];
		  ?>	
		  </p>
		  </div>
      </div>
    </div>
  </section>
   <a href="#" class="map-toggle arrow" id="map1">locate us on the map</a>

   <div class="google-map">
      <iframe src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0Dx_boXQiwvdz8sJHoYeZNVTdoWONYkU&q=astraeah+hotel+tagaytay" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>

  

  <footer>
    <div class="copyright">
        Copyright <i class="fa fa-copyright"></i>  2019 Astraea Guest House . All Rights Reserved
    </div>
</footer>
  <!--end footer-->
</div>
<script type="text/javascript">
  $(window).scroll(function(e){ 
  var $el = $('.bookingcontainer'); 
  var isPositionFixed = ($el.css('position') == 'fixed');
  if ($(this).scrollTop() > 200 && !isPositionFixed){ 
    $('.bookingcontainer').css({'position': 'fixed', 'top': '0px'}); 
  }
  if ($(this).scrollTop() < 200 && isPositionFixed)
  {
    $('.bookingcontainer').css({'position': 'static', 'top': '0px'}); 
  } 
});
</script>

<script>

Date.prototype.addDays = function(days) {
  var dat = new Date(this.valueOf());
  dat.setDate(dat.getDate() + days);
  return dat;
}

$(function(){
    var dtToday = new Date();
    dtToday = dtToday.addDays(0);
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate() + 1;
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + (day);
	$('#txtDate').attr('min', maxDate);
	$('#txtDate').val(maxDate);
	
	var inDate = $("#txtDate").val();
	var inDate_ = new Date(inDate);
	var inDatex = inDate_.addDays(1);
    var month_ = inDatex.getMonth() + 1;
    var day_ = inDatex.getDate();
    var year_ = inDatex.getFullYear();
    if(month_ < 10)
        month_ = '0' + month_.toString();
    if(day_ < 10)
        day_ = '0' + day_.toString();
	var tomorrow = year_ + '-' + month_ + '-' + (day_);
	
	$('#txtDateOut').attr('min', tomorrow);
	$('#txtDateOut').val(tomorrow);
});

function updDate(){
	var inDate = $("#txtDate").val();
	var inDate_ = new Date(inDate);
	var inDatex = inDate_.addDays(1);
    var month_ = inDatex.getMonth() + 1;
    var day_ = inDatex.getDate();
    var year_ = inDatex.getFullYear();
    if(month_ < 10)
        month_ = '0' + month_.toString();
    if(day_ < 10)
        day_ = '0' + day_.toString();
	var tomorrow = year_ + '-' + month_ + '-' + (day_);
	
	$('#txtDateOut').attr('min', tomorrow);
	$('#txtDateOut').val(tomorrow);
}

function date_(){
	var dtToday = new Date();
    dtToday = dtToday.addDays(0);
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate() + 1;
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;
    $('#txtDate').val(maxDate);
}

</script>



<!-- RED DATEPICKER 

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js'></script>

 
    <script  src="jsdd.js"></script> -->
</body>
</html>