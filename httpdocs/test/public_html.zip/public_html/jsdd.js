$('input.datepicker').datepicker({
		dateFormat: 'yy-mm-dd',
		showButtonPanel: true,
		changeMonth: true,
		changeYear: true,
		defaultDate: +0,
		showAnim: "fold"
	});

$('.datepicker.sample').datepicker({
		dateFormat: 'yy-mm-dd',
		showButtonPanel: true,
		changeMonth: true,
		changeYear: true,
		defaultDate: +0,
		showAnim: "fold"
	});