<?php
include ('../includes/header.php');
 ?>

<?php

include ('../includes/navbar.php');
include ('../includes/sidebar.php');
?>


    <!-- Page -->
    <div class="page">
      <div class="page-header">
          <h1 class="page-title">Add Employee</h1>
      </div>
      <div class="page-content container-fluid">
        <div class="row">

                    <div class="col-md-12">
                      <!-- Panel Floating Labels -->
                      <div class="panel">
                        <div class="panel-heading">
                          <h3 class="panel-title text-danger">* Required Field</h3>
                        </div>
                        <div class="panel-body container-fluid">


                        </div>
                      </div>
                      <!-- End Panel Floating Labels -->
                    </div>
        </div>
      </div>
    </div>
    <!-- End Page -->


    <!-- Footer -->
<?php
include ('../includes/footer.php');
include ('../includes/scripts.php');
 ?>


  </body>
</html>
